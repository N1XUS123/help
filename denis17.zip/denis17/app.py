import os
from datetime import datetime, timedelta
from functools import wraps
from flask import Flask, render_template, redirect, url_for, request, flash, jsonify, session
from flask_login import LoginManager, login_user, logout_user, login_required, current_user
from werkzeug.security import generate_password_hash, check_password_hash
from models import db, User, Restaurant, MenuItem, Order, OrderItem, BackupLog, Performance

app = Flask(__name__)
app.config['SECRET_KEY'] = 'restaurant-secret-key-2026-change-in-production'


DB_USERNAME = 'root'
DB_PASSWORD = ''
DB_HOST = 'localhost'
DB_PORT = '3306'
DB_NAME = 'restaurant_db'

app.config[
    'SQLALCHEMY_DATABASE_URI'] = f'mysql+pymysql://{DB_USERNAME}:{DB_PASSWORD}@{DB_HOST}:{DB_PORT}/{DB_NAME}?charset=utf8mb4'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['SQLALCHEMY_ENGINE_OPTIONS'] = {
    'pool_size': 10,
    'pool_recycle': 3600,
    'pool_pre_ping': True,
}
app.config['REMEMBER_COOKIE_DURATION'] = timedelta(days=7)
app.config['PERMANENT_SESSION_LIFETIME'] = timedelta(hours=8)

db.init_app(app)
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'
login_manager.login_message = '🔐 Пожалуйста, войдите в систему'
login_manager.login_message_category = 'info'



@app.context_processor
def utility_processor():

    from datetime import datetime
    return {
        'now': datetime.now,
        'app_name': 'Gourmet Restaurant System',
        'version': '2.0.3',
        'current_year': datetime.now().year,
        'today': datetime.now().strftime('%d.%m.%Y')
    }


@app.context_processor
def inject_user_role():

    return dict(has_role=lambda role: current_user.is_authenticated and current_user.role == role)


@app.context_processor
def inject_notifications_count():

    if current_user.is_authenticated:
        pending_orders = Order.query.filter_by(status='pending').count()
        failed_backups = BackupLog.query.filter_by(status='failed').count()
        return {'notifications_count': pending_orders + failed_backups}
    return {'notifications_count': 0}



@login_manager.user_loader
def load_user(user_id):
    return db.session.get(User, int(user_id))



def admin_required(f):


    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not current_user.is_authenticated:
            flash('Пожалуйста, войдите в систему', 'warning')
            return redirect(url_for('login'))
        if current_user.role != 'admin':
            flash('⛔ Доступ запрещен. Требуются права администратора.', 'danger')
            return redirect(url_for('dashboard'))
        return f(*args, **kwargs)

    return decorated_function


def permission_required(permission):


    def decorator(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            if not current_user.is_authenticated:
                return redirect(url_for('login'))

            return f(*args, **kwargs)

        return decorated_function

    return decorator



def log_action(action, details='', level='info'):

    timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    user = current_user.username if current_user.is_authenticated else 'anonymous'
    log_entry = f"[{timestamp}] [{level}] {user}: {action} - {details}"


    log_dir = 'logs'
    if not os.path.exists(log_dir):
        os.makedirs(log_dir)

    log_file = os.path.join(log_dir, f"{datetime.now().strftime('%Y-%m')}.log")
    with open(log_file, 'a', encoding='utf-8') as f:
        f.write(log_entry + '\n')


    print(log_entry)


    if level == 'error':

        pass



def init_database():

    with app.app_context():
        db.create_all()


        if not User.query.first():

            admin = User(
                username='admin',
                email='admin@restaurant.com',
                password_hash=generate_password_hash('admin123'),
                role='admin'
            )
            db.session.add(admin)


            restaurant = Restaurant(
                name='Gourmet Central',
                address='ул. Пушкина, 10',
                phone='+7 (999) 123-45-67',
                email='central@gourmet.com'
            )
            db.session.add(restaurant)
            db.session.commit()


            menu_items = [
                MenuItem(name='Цезарь с курицей', description='Классический салат с пармезаном',
                         price=450.0, category='Закуски', restaurant_id=restaurant.id),
                MenuItem(name='Стейк Рибай', description='Говядина на гриле с овощами',
                         price=1200.0, category='Основные блюда', restaurant_id=restaurant.id),
                MenuItem(name='Чизкейк', description='Нью-Йорк с ягодным соусом',
                         price=350.0, category='Десерты', restaurant_id=restaurant.id),
                MenuItem(name='Лимонад', description='Домашний лимонад с мятой',
                         price=250.0, category='Напитки', restaurant_id=restaurant.id),
            ]
            for item in menu_items:
                db.session.add(item)


            performance = Performance(
                name='Вечерний ужин с музыкой',
                date=datetime.now() + timedelta(days=7),
                price=2500.0,
                description='Романтический вечер с живой музыкой'
            )
            db.session.add(performance)

            db.session.commit()
            print("✅ База данных инициализирована с тестовыми данными")


            log_action('system_init', 'База данных создана', 'info')
        else:
            print("✅ База данных уже существует")



init_database()



@app.route('/')
def index():

    if current_user.is_authenticated:
        return redirect(url_for('dashboard'))
    return redirect(url_for('login'))


@app.route('/login', methods=['GET', 'POST'])
def login():

    if current_user.is_authenticated:
        return redirect(url_for('dashboard'))

    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        remember = True if request.form.get('remember') else False

        user = User.query.filter_by(username=username).first()

        if user and check_password_hash(user.password_hash, password):
            login_user(user, remember=remember)
            session.permanent = True

            log_action('login', f'Успешный вход пользователя {username}', 'info')


            next_page = request.args.get('next')
            if next_page and next_page.startswith('/'):
                return redirect(next_page)

            flash(f'👋 Добро пожаловать, {user.username}!', 'success')
            return redirect(url_for('dashboard'))
        else:
            log_action('login', f'Неудачная попытка входа для {username}', 'warning')
            flash('❌ Неверное имя пользователя или пароль', 'danger')

    return render_template('login.html')


@app.route('/register', methods=['GET', 'POST'])
def register():

    if current_user.is_authenticated:
        return redirect(url_for('dashboard'))

    if request.method == 'POST':
        username = request.form.get('username')
        email = request.form.get('email')
        password = request.form.get('password')
        confirm = request.form.get('confirm')


        if not username or not email or not password:
            flash('⚠️ Все поля обязательны для заполнения', 'warning')
            return redirect(url_for('register'))

        if password != confirm:
            flash('❌ Пароли не совпадают', 'danger')
            return redirect(url_for('register'))

        if len(password) < 6:
            flash('❌ Пароль должен быть не менее 6 символов', 'danger')
            return redirect(url_for('register'))


        if User.query.filter_by(username=username).first():
            flash('❌ Имя пользователя уже занято', 'danger')
            return redirect(url_for('register'))

        if User.query.filter_by(email=email).first():
            flash('❌ Email уже зарегистрирован', 'danger')
            return redirect(url_for('register'))


        hashed_password = generate_password_hash(password)
        new_user = User(
            username=username,
            email=email,
            password_hash=hashed_password,
            role='staff'
        )
        db.session.add(new_user)
        db.session.commit()

        log_action('register', f'Новый пользователь: {username}', 'info')

        flash('✅ Регистрация успешна! Теперь вы можете войти.', 'success')
        return redirect(url_for('login'))

    return render_template('register.html')


@app.route('/dashboard')
@login_required
def dashboard():


    restaurants_count = Restaurant.query.count()
    users_count = User.query.count()
    menu_count = MenuItem.query.count()

    today = datetime.today().date()
    orders_today = Order.query.filter(
        db.func.date(Order.created_at) == today
    ).count()

    revenue_today = db.session.query(
        db.func.coalesce(db.func.sum(Order.total_amount), 0)
    ).filter(
        db.func.date(Order.created_at) == today
    ).scalar()

    pending_orders = Order.query.filter_by(status='pending').count()
    preparing_orders = Order.query.filter_by(status='preparing').count()


    active_orders = Order.query.filter(
        Order.status.in_(['pending', 'preparing'])
    ).order_by(Order.created_at.desc()).limit(5).all()

    log_action('dashboard_view', f'Просмотр дашборда', 'info')

    return render_template('dashboard.html',
                           restaurants_count=restaurants_count,
                           users_count=users_count,
                           menu_count=menu_count,
                           orders_today=orders_today,
                           revenue_today=revenue_today,
                           pending_orders=pending_orders,
                           preparing_orders=preparing_orders,
                           active_orders=active_orders)


@app.route('/admin')
@login_required
@admin_required
def admin_panel():

    tab = request.args.get('tab', 'dashboard')


    restaurants = Restaurant.query.all()
    users = User.query.all()
    menu_items = MenuItem.query.all()
    backups = BackupLog.query.order_by(BackupLog.created_at.desc()).limit(20).all()


    total_revenue = db.session.query(
        db.func.coalesce(db.func.sum(Order.total_amount), 0)
    ).scalar()

    total_orders = Order.query.count()
    total_restaurants = Restaurant.query.count()
    total_users = User.query.count()


    last_7_days = []
    revenue_data = []
    for i in range(6, -1, -1):
        date = datetime.today().date() - timedelta(days=i)
        last_7_days.append(date.strftime('%d.%m'))

        daily_revenue = db.session.query(
            db.func.coalesce(db.func.sum(Order.total_amount), 0)
        ).filter(
            db.func.date(Order.created_at) == date
        ).scalar()
        revenue_data.append(float(daily_revenue))

    log_action('admin_panel', f'Просмотр вкладки {tab}', 'info')

    return render_template('admin_panel.html',
                           tab=tab,
                           restaurants=restaurants,
                           users=users,
                           menu_items=menu_items,
                           backups=backups,
                           total_revenue=total_revenue,
                           total_orders=total_orders,
                           total_restaurants=total_restaurants,
                           total_users=total_users,
                           last_7_days=last_7_days,
                           revenue_data=revenue_data)


@app.route('/sales-report')
@login_required
def sales_report():


    date_from = request.args.get('date_from')
    date_to = request.args.get('date_to')
    performance_id = request.args.get('performance')


    query = Order.query


    if date_from:
        try:
            date_from_obj = datetime.strptime(date_from, '%Y-%m-%d')
            query = query.filter(Order.created_at >= date_from_obj)
        except:
            flash('⚠️ Неверный формат даты "с". Используйте ГГГГ-ММ-ДД', 'warning')

    if date_to:
        try:
            date_to_obj = datetime.strptime(date_to, '%Y-%m-%d')
            date_to_obj = date_to_obj.replace(hour=23, minute=59, second=59)
            query = query.filter(Order.created_at <= date_to_obj)
        except:
            flash('⚠️ Неверный формат даты "по"', 'warning')

    orders = query.all()


    try:
        performances = Performance.query.all()
    except:
        performances = []


    total_sales = len(orders)
    total_revenue = sum(order.total_amount for order in orders) if orders else 0

    sales_details = []
    for order in orders:
        sales_details.append({
            'id': order.id,
            'date': order.created_at.strftime('%d.%m.%Y %H:%M'),
            'order_number': order.order_number if hasattr(order, 'order_number') else f'#{order.id}',
            'performance_name': f'Заказ #{order.id}',
            'tickets_count': 1,
            'amount': order.total_amount,
            'status': order.status
        })

    sales_data = {
        'total_sales': total_sales,
        'total_revenue': total_revenue,
        'avg_revenue': round(total_revenue / total_sales, 2) if total_sales > 0 else 0,
        'total_tickets': total_sales,
        'details': sales_details
    }

    log_action('sales_report', f'Сформирован отчет за период {date_from} - {date_to}', 'info')

    return render_template('sales_report.html',
                           sales_data=sales_data,
                           performances=performances,
                           date_from=date_from,
                           date_to=date_to)



@app.route('/api/notifications')
@login_required
def get_notifications():

    notifications = []


    pending_orders = Order.query.filter_by(status='pending').count()
    if pending_orders > 0:
        notifications.append({
            'type': 'info',
            'icon': '📦',
            'title': f'{pending_orders} заказов ожидают обработки',
            'message': 'Требуется назначить повара',
            'time': 'сейчас',
            'url': url_for('admin_panel', tab='orders')
        })

    preparing_orders = Order.query.filter_by(status='preparing').count()
    if preparing_orders > 0:
        notifications.append({
            'type': 'warning',
            'icon': '👨‍🍳',
            'title': f'{preparing_orders} заказов в процессе приготовления',
            'message': 'Повара работают',
            'time': 'сейчас',
            'url': url_for('admin_panel', tab='orders')
        })


    failed_backups = BackupLog.query.filter_by(status='failed').count()
    if failed_backups > 0:
        notifications.append({
            'type': 'error',
            'icon': '❌',
            'title': f'{failed_backups} бэкапов завершились ошибкой',
            'message': 'Требуется проверить настройки',
            'time': 'сегодня',
            'url': url_for('admin_panel', tab='backups')
        })


    low_stock_items = MenuItem.query.filter_by(is_available=False).count()
    if low_stock_items > 0:
        notifications.append({
            'type': 'warning',
            'icon': '⚠️',
            'title': f'{low_stock_items} блюд нет в наличии',
            'message': 'Требуется обновить меню',
            'time': 'сегодня',
            'url': url_for('admin_panel', tab='menu')
        })

    return jsonify({
        'count': len(notifications),
        'notifications': notifications,
        'timestamp': datetime.now().isoformat()
    })


@app.route('/api/search')
@login_required
def global_search():

    query = request.args.get('q', '').strip()
    if len(query) < 2:
        return jsonify({'results': [], 'total': 0})

    results = []


    menu_items = MenuItem.query.filter(
        MenuItem.name.contains(query) |
        MenuItem.description.contains(query)
    ).limit(3)

    for item in menu_items:
        results.append({
            'type': 'menu',
            'icon': '🍽️',
            'name': item.name,
            'url': url_for('admin_panel', tab='menu'),
            'description': f"{item.price} ₽ • {item.category}",
            'badge': item.category
        })


    restaurants = Restaurant.query.filter(
        Restaurant.name.contains(query) |
        Restaurant.address.contains(query)
    ).limit(3)

    for rest in restaurants:
        results.append({
            'type': 'restaurant',
            'icon': '🏢',
            'name': rest.name,
            'url': url_for('admin_panel', tab='restaurants'),
            'description': rest.address or 'Адрес не указан',
            'badge': 'Активен' if rest.is_active else 'Неактивен'
        })


    users = User.query.filter(
        User.username.contains(query) |
        User.email.contains(query)
    ).limit(3)

    for user in users:
        results.append({
            'type': 'user',
            'icon': '👤',
            'name': user.username,
            'url': url_for('admin_panel', tab='users'),
            'description': user.email,
            'badge': user.role
        })

    return jsonify({
        'results': results,
        'total': len(results),
        'query': query
    })


@app.route('/api/stats/live')
@login_required
def live_stats():

    today = datetime.today().date()
    now = datetime.now()


    orders_today = Order.query.filter(
        db.func.date(Order.created_at) == today
    ).count()


    revenue_today = db.session.query(
        db.func.coalesce(db.func.sum(Order.total_amount), 0)
    ).filter(
        db.func.date(Order.created_at) == today
    ).scalar()


    active_orders = Order.query.filter(
        Order.status.in_(['pending', 'preparing'])
    ).count()


    completed_today = Order.query.filter(
        db.func.date(Order.created_at) == today,
        Order.status == 'completed'
    ).count()


    avg_time = 15

    return jsonify({
        'orders_today': orders_today,
        'revenue_today': float(revenue_today),
        'active_orders': active_orders,
        'completed_today': completed_today,
        'avg_time': avg_time,
        'timestamp': now.strftime('%H:%M:%S'),
        'date': now.strftime('%d.%m.%Y')
    })


@app.route('/api/performance/items')
@login_required
def popular_items():


    popular = [
        {'name': 'Цезарь с курицей', 'orders': 45, 'revenue': 20250},
        {'name': 'Стейк Рибай', 'orders': 32, 'revenue': 38400},
        {'name': 'Чизкейк', 'orders': 28, 'revenue': 9800},
        {'name': 'Лимонад', 'orders': 25, 'revenue': 6250},
        {'name': 'Борщ', 'orders': 18, 'revenue': 5400},
    ]
    return jsonify(popular)


@app.route('/api/performance/hourly')
@login_required
def hourly_stats():


    hours = [f'{i}:00' for i in range(8, 24)]
    orders = [5, 8, 12, 15, 18, 22, 25, 20, 18, 15, 10, 7, 5, 3, 2, 1]

    return jsonify({
        'labels': hours,
        'data': orders
    })



@app.route('/add_restaurant', methods=['POST'])
@login_required
@admin_required
def add_restaurant():

    name = request.form.get('name')
    address = request.form.get('address')
    phone = request.form.get('phone')
    email = request.form.get('email')

    if not name:
        flash('⚠️ Название ресторана обязательно', 'warning')
        return redirect(url_for('admin_panel', tab='restaurants'))

    restaurant = Restaurant(
        name=name,
        address=address,
        phone=phone,
        email=email
    )
    db.session.add(restaurant)
    db.session.commit()

    log_action('add_restaurant', f'Добавлен ресторан: {name}', 'info')
    flash(f'✅ Ресторан "{name}" успешно добавлен', 'success')

    return redirect(url_for('admin_panel', tab='restaurants'))


@app.route('/add_user', methods=['POST'])
@login_required
@admin_required
def add_user():

    username = request.form.get('username')
    email = request.form.get('email')
    password = request.form.get('password')
    role = request.form.get('role', 'staff')
    restaurant_id = request.form.get('restaurant_id')


    if not username or not email or not password:
        flash('⚠️ Все поля обязательны', 'warning')
        return redirect(url_for('admin_panel', tab='users'))

    if User.query.filter_by(username=username).first():
        flash('❌ Имя пользователя уже занято', 'danger')
        return redirect(url_for('admin_panel', tab='users'))

    if User.query.filter_by(email=email).first():
        flash('❌ Email уже зарегистрирован', 'danger')
        return redirect(url_for('admin_panel', tab='users'))

    hashed_password = generate_password_hash(password)
    user = User(
        username=username,
        email=email,
        password_hash=hashed_password,
        role=role,
        restaurant_id=int(restaurant_id) if restaurant_id else None
    )
    db.session.add(user)
    db.session.commit()

    log_action('add_user', f'Добавлен пользователь: {username} с ролью {role}', 'info')
    flash(f'✅ Пользователь {username} успешно добавлен', 'success')

    return redirect(url_for('admin_panel', tab='users'))


@app.route('/add_menu_item', methods=['POST'])
@login_required
def add_menu_item():

    name = request.form.get('name')
    description = request.form.get('description')
    price = request.form.get('price')
    category = request.form.get('category')
    restaurant_id = request.form.get('restaurant_id')


    if not name or not price:
        flash('⚠️ Название и цена обязательны', 'warning')
        return redirect(url_for('admin_panel', tab='menu'))

    try:
        price = float(price)
        if price <= 0:
            raise ValueError
    except:
        flash('⚠️ Цена должна быть положительным числом', 'warning')
        return redirect(url_for('admin_panel', tab='menu'))

    menu_item = MenuItem(
        name=name,
        description=description,
        price=price,
        category=category,
        restaurant_id=int(restaurant_id) if restaurant_id else 1
    )
    db.session.add(menu_item)
    db.session.commit()

    log_action('add_menu_item', f'Добавлено блюдо: {name} за {price} ₽', 'info')
    flash(f'✅ Блюдо "{name}" добавлено в меню', 'success')

    return redirect(url_for('admin_panel', tab='menu'))


@app.route('/create_backup', methods=['POST'])
@login_required
@admin_required
def create_backup():


    backup_dir = 'backups'
    if not os.path.exists(backup_dir):
        os.makedirs(backup_dir)

    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    filename = f"backup_{timestamp}.sql"
    filepath = os.path.join(backup_dir, filename)

    try:

        with open(filepath, 'w', encoding='utf-8') as f:
            f.write(f"-- Backup created at {datetime.now()}\n")
            f.write(f"-- Database: {DB_NAME}\n")
            f.write("-- This is a simulated backup file\n")

        size = os.path.getsize(filepath)

        backup = BackupLog(
            filename=filename,
            status='success',
            size=size,
            completed_at=datetime.now()
        )

        log_action('create_backup', f'Создан бэкап: {filename}', 'info')
        flash(f'✅ Бэкап успешно создан: {filename}', 'success')

    except Exception as e:
        backup = BackupLog(
            filename=filename,
            status='failed',
            size=0,
            completed_at=datetime.now()
        )
        log_action('create_backup', f'Ошибка создания бэкапа: {str(e)}', 'error')
        flash(f'❌ Ошибка создания бэкапа: {str(e)}', 'danger')

    db.session.add(backup)
    db.session.commit()

    return redirect(url_for('admin_panel', tab='backups'))



@app.route('/toggle_restaurant/<int:id>', methods=['POST'])
@login_required
@admin_required
def toggle_restaurant(id):

    restaurant = db.session.get(Restaurant, id)
    if restaurant:
        restaurant.is_active = not restaurant.is_active
        db.session.commit()
        status = 'активирован' if restaurant.is_active else 'деактивирован'
        log_action('toggle_restaurant', f'Ресторан {restaurant.name} {status}', 'info')
        return jsonify({'success': True, 'status': restaurant.is_active})
    return jsonify({'success': False, 'error': 'Ресторан не найден'}), 404


@app.route('/delete_user/<int:id>', methods=['POST'])
@login_required
@admin_required
def delete_user(id):

    user = db.session.get(User, id)
    if user and user.id != current_user.id:  # Не даем удалить самого себя
        username = user.username
        db.session.delete(user)
        db.session.commit()
        log_action('delete_user', f'Удален пользователь: {username}', 'warning')
        return jsonify({'success': True})
    return jsonify({'success': False, 'error': 'Пользователь не найден'}), 404


@app.route('/toggle_menu_item/<int:id>', methods=['POST'])
@login_required
def toggle_menu_item(id):

    menu_item = db.session.get(MenuItem, id)
    if menu_item:
        menu_item.is_available = not menu_item.is_available
        db.session.commit()
        status = 'доступно' if menu_item.is_available else 'недоступно'
        return jsonify({'success': True, 'status': menu_item.is_available})
    return jsonify({'success': False, 'error': 'Блюдо не найдено'}), 404


@app.route('/delete_menu_item/<int:id>', methods=['POST'])
@login_required
@admin_required
def delete_menu_item(id):

    menu_item = db.session.get(MenuItem, id)
    if menu_item:
        name = menu_item.name
        db.session.delete(menu_item)
        db.session.commit()
        log_action('delete_menu_item', f'Удалено блюдо: {name}', 'warning')
        return jsonify({'success': True})
    return jsonify({'success': False, 'error': 'Блюдо не найдено'}), 404



@app.route('/save_backup_settings', methods=['POST'])
@login_required
@admin_required
def save_backup_settings():

    auto_backup = request.form.get('auto_backup') == 'on'
    retention_days = int(request.form.get('retention_days', 14))
    backup_time = int(request.form.get('backup_time', 3))


    flash('✅ Настройки бэкапов сохранены', 'success')
    return redirect(url_for('admin_panel', tab='backups'))


@app.route('/save_security', methods=['POST'])
@login_required
@admin_required
def save_security():
    """Сохранение настроек безопасности"""
    min_length = int(request.form.get('min_length', 8))
    require_digits = request.form.get('require_digits') == 'on'
    require_uppercase = request.form.get('require_uppercase') == 'on'
    max_attempts = int(request.form.get('max_attempts', 5))


    flash('✅ Настройки безопасности сохранены', 'success')
    return redirect(url_for('admin_panel', tab='security'))



@app.route('/logout')
@login_required
def logout():

    username = current_user.username
    logout_user()
    log_action('logout', f'Пользователь {username} вышел из системы', 'info')
    flash('👋 Вы вышли из системы', 'info')
    return redirect(url_for('login'))



@app.errorhandler(404)
def page_not_found(e):

    return render_template('404.html'), 404


@app.errorhandler(500)
def internal_server_error(e):

    db.session.rollback()
    log_action('server_error', str(e), 'error')
    return render_template('500.html'), 500


@app.errorhandler(403)
def forbidden(e):

    flash('⛔ У вас нет прав для доступа к этой странице', 'danger')
    return redirect(url_for('dashboard'))



if __name__ == '__main__':
    print("=" * 50)
    print("🍽️  Gourmet Restaurant System v2.0.3")
    print("=" * 50)
    print(f"📅  Дата запуска: {datetime.now().strftime('%d.%m.%Y %H:%M')}")
    print(f"🐍  Режим: Debug")
    print(f"🗄️  База данных: MySQL (XAMPP)")
    print(f"🌐  URL: http://127.0.0.1:5000")
    print("=" * 50)
    print("👤  Тестовый доступ: admin / admin123")
    print("=" * 50)

    app.run(debug=True, host='0.0.0.0', port=5000)